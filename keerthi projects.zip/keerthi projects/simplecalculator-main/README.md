# Simple Android Calculator

### Features

1. Addition, Multiplication, Substraction, Division, Percentage, Logarithm, Exponential, Root, Sin, Cos, Tan, Root.
2. About menu for toast text (Appears for 2 seconds in bottom).
3. Round buttons with ripple effects.
4. Close Menu for exit.

## Screenshots:

#### My app:

<img src="https://github.com/KasRoudra/simplecalculator/raw/main/my.jpeg">

#### Source app:

<img src="https://github.com/KasRoudra/simplecalculator/raw/main/source.jpeg">

### Source Code credit <a href="https://github.com/CMDann/Simple-Android-Calculator">CMDann</a>

#### Developed for learning purposes. New java learners can easlily understand how calculator works by this small and simple app.