class Quiz {
  final int quiz_id;
  final String quiz_description;
  final quiz_category;
  Quiz(this.quiz_id, this.quiz_category, this.quiz_description);
}
